package com.example.multimediaHub.web;

import com.example.multimediaHub.config.UserData;
import com.example.multimediaHub.model.User;

import com.example.multimediaHub.service.UserService;
import com.example.multimediaHub.web.dto.Register;
import com.example.multimediaHub.web.enums.WalletBackground;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;


@Controller
@RequestMapping("/wallet")
public class WalletController {

    private final UserService userService;

    public WalletController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public String wallet(Model model, @AuthenticationPrincipal UserData userData) {
        // Вземаме най-актуалния User от базата
        User user = userService.findUserById(userData.getUserId());
        model.addAttribute("user", user);

        // Подготвяме DTO за формата
        if (!model.containsAttribute("register")) {
            Register register = new Register();
            register.setWalletBalance(BigDecimal.ZERO); // да има default
            model.addAttribute("register", register);
        }

        // Случайна background картинка
        model.addAttribute("backgroundImage", WalletBackground.random().getImageName());

        return "wallet";
    }

    @PostMapping
    public String chargeWallet(@AuthenticationPrincipal UserData userData,
                               @Valid @ModelAttribute("register") Register register,
                               BindingResult bindingResult,
                               RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute(
                    "org.springframework.validation.BindingResult.register", bindingResult);
            redirectAttributes.addFlashAttribute("register", register);
            return "redirect:/wallet";
        }

        // Зареждаме баланса
        userService.chargeWallet(userData.getUsername(), register.getWalletBalance());

        // След зареждането – пренасочваме към Wallet отново, за да видим актуалния баланс
        return "redirect:/wallet";
    }
}