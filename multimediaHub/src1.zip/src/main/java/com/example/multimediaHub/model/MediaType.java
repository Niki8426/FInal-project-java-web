package com.example.multimediaHub.model;

public enum MediaType {
    MUSIC, MOVIE
}