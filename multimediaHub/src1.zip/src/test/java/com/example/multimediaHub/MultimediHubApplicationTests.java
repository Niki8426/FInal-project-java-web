package com.example.multimediaHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultimediHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
