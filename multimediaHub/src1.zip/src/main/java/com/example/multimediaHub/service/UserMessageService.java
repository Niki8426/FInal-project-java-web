package com.example.multimediaHub.service;


import org.springframework.stereotype.Service;

@Service
public class UserMessageService {


}
